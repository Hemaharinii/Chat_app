import React from "react";
import ReactDOM from 'react-dom'
import { If } from "react-if";
// import io from "socket.io-client";
import {
  ButtonToolbar,
  ButtonGroup,
  Button,
  Row,
  Col,
  Grid,
  Panel,
  ListGroupItem,
  ListGroup
} from "react-bootstrap";

class Chat extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      listItems: [],
      singleListItem: {},
      receivedNo: "",
      newNo: "",
      myNumber: "",
      yourNumber: "",
      show: false
    };
  }
  componentDidMount() {
    this.getMessageList();
    var messageListInterval = setInterval(() => {
     this.getMessageList();
   }, 5000);
  }

  componentWillUnmount() {
   clearInterval(this.messageListInterval);
   // clearInterval(this.updateMessageListInterval);
  }

  fetchOnClick = id => {
    fetch("http://localhost:5000/conversations/" + id)
      .then(results => {
        return results.json();
      })
      .then(data => {
        this.setState({
          receivedNo: data
            ? data.phoneNumber1 !== this.state.myNumber
              ? data.phoneNumber1
              : data.phoneNumber2
            : ""
        });
        this.setState({ singleListItem: data });
        this.scrollToBottom();
      });
  };
  getMessageList() {
    fetch(
      "http://localhost:5000/conversations?phoneNumber=" + this.state.myNumber
    )
      .then(results => {
        return results.json();
      })
      .then(data => {
        this.setState({ listItems: data });
        if (this.state.listItems && this.state.listItems.length > 0 && !this.state.singleListItem.conversations) {
          this.fetchOnClick(this.state.listItems[0]._id);
       }
       if(this.state.singleListItem.conversations)
         this.refreshLeftSide();
      });
  }
  refreshLeftSide() {
    let singleItemNew = this.state.listItems.find( listItem =>{
      return listItem._id === this.state.singleListItem._id;
    })
    if( singleItemNew && this.state.singleListItem.conversations && (singleItemNew.conversations.length !== this.state.singleListItem.conversations.length )){
      this.setState({ singleListItem : singleItemNew })
    }
  }
  sendMessageToNewNumber() {
    if (this.state.newNo === "") {
      alert("Enter the receipient number");
    } else {
      this.state.receivedNo = this.state.newNo
      this.setState({ show: false });
      this.sendMessageToNewNumberToServer();
    }
  }
  cancelMessageToNewNumber() {
    this.setState({ show: false });
    this.getMessageList();
  }

  sendMessageToNewNumberToServer() {
    fetch("http://localhost:5000/conversations", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      credentials: "same-origin",
      body: JSON.stringify({
        phoneNumber1: this.state.myNumber,
        phoneNumber2: this.state.receivedNo,
        messageText: this.state.message,
        senderNumber: this.state.myNumber
      })
    })
      .then(res => res.json())
      .then(data => {
        this.setState({ message: "" });
        this.getMessageList();
      })
      .catch(err => console.log(err));
  }

  updateNumber(no) {
    this.state.myNumber = no;
    this.getMessageList();
  }

  sendToNewNumber() {
    this.setState({ receivedNo: "" });
    this.setState({ singleListItem: {} });
    this.setState({ show: true });
  }

  updateMessageToHost(id) {
    fetch("http://localhost:5000/conversations/" + id, {
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      credentials: "same-origin",
      body: JSON.stringify({
        phoneNumber1: this.state.myNumber,
        phoneNumber2: this.state.receivedNo,
        messageText: this.state.message,
        senderNumber: this.state.myNumber
      })
    })
      .then(res => res.json())
      .then(data => {
        this.setState({ message: "" });
        this.setState({
          receivedNo: data
            ? data.phoneNumber1 !== this.state.myNumber
              ? data.phoneNumber1
              : data.phoneNumber2
            : ""
        });
        this.setState({ singleListItem: data });
        this.scrollToBottom();
      })
      .catch(err => console.log(err));
  }

  scrollToBottom = () => {
   const messagesContainer = ReactDOM.findDOMNode(this.messagesContainer);
   if(messagesContainer)
   messagesContainer.scrollTop = messagesContainer.scrollHeight;
};

  render() {
    return (
      <div>
        <If condition={this.state.myNumber !== ""}>
          <Grid>
            <Row>
              <Col style={{ margin: "13px 50px 12px 10px" }} xs={6} md={4}>
                <If condition={!this.state.show}>
                  <Panel>
                    <Panel.Heading>
                      <Panel.Title componentClass="h3">
                        CHAT HISTORY{" "}
                      </Panel.Title>
                    </Panel.Heading>
                    <Button
                      bsStyle="info"
                      style={{ margin: "0px 0px 12px 0px" }}
                      onClick={() => this.sendToNewNumber()}
                      className="btn btn-primary form-control"
                    >
                      Start new conversation
                    </Button>

                    <ListGroup style={{ maxHeight : "500px", overflowY : "scroll" }}>
                      {this.state.listItems.map(listItem => {
                        return (
                          <ListGroupItem
                            class="list-group-item"
                            href="#"
                            active={
                              this.state.singleListItem._id === listItem._id
                                ? true
                                : false
                            }
                            onClick={() => this.fetchOnClick(listItem._id)}
                          >
                            <span>
                              Chat with:{" "}
                              {listItem.phoneNumber1 !== this.state.myNumber
                                ? listItem.phoneNumber1
                                : listItem.phoneNumber2}{" "}
                            </span> <br />
                            <span>
                              last message:{" "}
                              {listItem.conversations.length > 0
                                ? listItem.conversations[
                                    listItem.conversations.length - 1
                                  ].messageText
                                : ""}
                            </span>
                          </ListGroupItem>
                        );
                      })}
                    </ListGroup>

                    <div />
                  </Panel>
                </If>
              </Col>
              <Col xs={12} md={6}>
                <If
                  condition={
                    this.state.singleListItem &&
                    this.state.singleListItem.conversations && !this.state.show
                  }
                >
                  <Panel>
                    <Panel.Heading>
                      <Panel.Title componentClass="h3">
                        Chat with {this.state.receivedNo}{" "}
                      </Panel.Title>
                    </Panel.Heading>

                    <ListGroup ref={(el) => { this.messagesContainer = el; }} 
                     className="MessageList" style={{ margin: "0px 0px 12px 0px" , maxHeight : "500px", overflowY : "scroll"}}>
                      {this.state.singleListItem &&
                      this.state.singleListItem.conversations
                        ? this.state.singleListItem.conversations.map(
                            conversationslistItem => {
                              return (
                                <ListGroupItem class="list-group-item">
                                  <If
                                    condition={
                                      conversationslistItem.senderNumber ===
                                      this.state.myNumber
                                    }
                                  >
                                    <span style={{ float: "right" }}>
                                      {conversationslistItem.messageText}
                                    </span>
                                  </If>
                                  <If
                                    condition={
                                      conversationslistItem.senderNumber !==
                                      this.state.myNumber
                                    }
                                  >
                                    <span style={{ float: "left" }}>
                                      {conversationslistItem.messageText}
                                    </span>
                                  </If>
                                </ListGroupItem>
                              );
                            }
                          )
                        : ""}
                    </ListGroup>
                    <div className="card-footer">
                      <input
                        type="text"
                        placeholder="Message"
                        className="form-control"
                        value={this.state.message}
                        onChange={ev =>
                          this.setState({ message: ev.target.value })
                        }
                      />
                      <br />
                      <button
                        onClick={() =>
                          this.updateMessageToHost(
                            this.state.singleListItem._id
                          )
                        }
                        className="btn btn-primary form-control"
                      >
                        Send
                      </button>
                    </div>
                  </Panel>
                </If>
              </Col>
            </Row>
          </Grid>
        </If>
        <If condition={this.state.show}>
          <Panel>
            <Panel.Heading>
              <Panel.Title componentClass="h3">
                New Conversation
              </Panel.Title>
            </Panel.Heading>
            <div>
              <input
                type="text"
                placeholder="Please enter the receiver number"
                className="form-control"
                type="number"
                value={this.state.newNo}
                onChange={ev => this.setState({ newNo: ev.target.value })}
              />
              <br />
              <input
                type="text"
                placeholder="Message"
                className="form-control"
                value={this.state.message}
                onChange={ev => this.setState({ message: ev.target.value })}
              />
              <br />
              <ButtonToolbar>
                <ButtonGroup>
                  <Button
                    onClick={() => this.sendMessageToNewNumber()}
                    className="btn btn-primary form-control"
                  >
                    Send Message
                  </Button>
                </ButtonGroup>
                <ButtonGroup>
                  <Button
                    onClick={() =>
                      this.cancelMessageToNewNumber(this.state.yourNumber)
                    }
                    className="btn btn-primary form-control"
                  >
                    Cancel

                  </Button>
                </ButtonGroup>
              </ButtonToolbar>
            </div>
          </Panel>
        </If>
        <If condition={this.state.myNumber === ""}>
          <div>
           
            <input
              type="text"
              placeholder="Please enter your number"
              className="form-control"
              type="number"
              value={this.state.yourNumber}
              onChange={ev => this.setState({ yourNumber: ev.target.value })}
            />
            <button
              onClick={() => this.updateNumber(this.state.yourNumber)}
              className="btn btn-primary form-control"
            >
              Submit
            </button>
          </div>
        </If>
      </div>
    );
  }
}

export default Chat;
