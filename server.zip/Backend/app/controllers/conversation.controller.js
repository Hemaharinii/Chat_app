var Conversation = require("../models/conversation.model.js");

exports.create = function(req, res) {
  // Create and Save a new conversation
  console.log(req.body);
  if (!req.body.phoneNumber1 || !req.body.phoneNumber2) {
    return res
      .status(400)
      .send({ message: "Required property is not present" });
  }
  Conversation.findOne({
    $or: [
      {
        phoneNumber1: req.body.phoneNumber1,
        phoneNumber2: req.body.phoneNumber2
      },
      {
        phoneNumber2: req.body.phoneNumber1,
        phoneNumber1: req.body.phoneNumber2
      }
    ]
  }).exec(function(err, conversation) {
    if (err) {
      console.log(err);
      res
        .status(500)
        .send({
          message: "Some error occurred while retrieving conversation."
        });
    } else {
      if (conversation) {
        var lConversation = {};
        lConversation.senderNumber = req.body.senderNumber;
        lConversation.timeSent = new Date();
        lConversation.messageText = req.body.messageText;
        conversation.conversations.push(lConversation);
      } else {
        var conversation = new Conversation();
        conversation.phoneNumber1 = req.body.phoneNumber1;
        conversation.phoneNumber2 = req.body.phoneNumber2;
        conversation.conversations = [];
        var lConversation = {};
        lConversation.senderNumber = req.body.senderNumber;
        lConversation.timeSent = new Date();
        lConversation.messageText = req.body.messageText;
        conversation.conversations.push(lConversation);
      }
      conversation.save(function(err, data) {
        if (err) {
          console.log(err);
          res
            .status(500)
            .send({
              message: "Some error occurred while creating the conversation."
            });
        } else {
          res.send(data);
        }
      });
    }
  });
};

exports.findAll = function(req, res) {
  // Retrieve and return all conversations from the database.
  Conversation.find({$or: [
   {
    phoneNumber1: req.query.phoneNumber,
  },
  {
    phoneNumber2: req.query.phoneNumber,
  }
  ]}).exec(function(err, conversations) {
    if (err) {
      console.log(err);
      res
        .status(500)
        .send({
          message: "Some error occurred while retrieving conversation."
        });
    } else {
      res.send(conversations);
    }
  });
};

exports.findOne = function(req, res) {
  // Find a single conversation with a conversationId
  Conversation.findById(req.params.conversationId, function(err, conversation) {
    if (err) {
      console.log(err);
      if (err.kind === "ObjectId") {
        return res
          .status(404)
          .send({
            message:
              "conversation not found with id " + req.params.conversationId
          });
      }
      return res
        .status(500)
        .send({
          message:
            "Error retrieving conversation with id " + req.params.conversationId
        });
    }

    if (!conversation) {
      return res
        .status(404)
        .send({
          message: "conversation not found with id " + req.params.conversationId
        });
    }

    res.send(conversation);
  });
};


exports.delete = function(req, res) {
 Conversation.findByIdAndRemove(req.params.conversationId, function(err, conversation) {
  if(err) {
      console.log(err);
      if(err.kind === 'ObjectId') {
          return res.status(404).send({message: "conversation not found with id " + req.params.conversationId});                
      }
      return res.status(500).send({message: "Could not delete conversation with id " + req.params.conversationId});
  }

  if(!conversation) {
      return res.status(404).send({message: "conversation not found with id " + req.params.conversationId});
  }

  res.send({message: "conversation deleted successfully!"})
});

};


exports.update = function(req, res) {
 // Update a conversation identified by the conversationId in the request
 Conversation.findById(req.params.conversationId, function(err, conversation) {
  if(err) {
      console.log(err);
      if(err.kind === 'ObjectId') {
          return res.status(404).send({message: "conversation not found with id " + req.params.conversationId});                
      }
      return res.status(500).send({message: "Error finding conversation with id " + req.params.conversationId});
  }

  if(!conversation) {
      return res.status(404).send({message: "conversation not found with id " + req.params.conversationId});            
  }

  var lConversation = {};
  lConversation.senderNumber = req.body.senderNumber;
  lConversation.timeSent = new Date();
  lConversation.messageText = req.body.messageText;
  conversation.conversations.push(lConversation);

  conversation.save(function(err, data){
      if(err) {
          res.status(500).send({message: "Could not update conversation with id " + req.params.conversationId});
      } else {
          res.send(data);
      }
  });
});
};