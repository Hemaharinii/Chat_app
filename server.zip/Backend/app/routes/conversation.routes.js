module.exports = function(app) {

 var conversations = require('../controllers/conversation.controller.js');

 // Create a new conversation
 app.post('/conversations', conversations.create);

 // Retrieve all conversations
 app.get('/conversations', conversations.findAll);

 // Retrieve a single conversation with conversationId
 app.get('/conversations/:conversationId', conversations.findOne);

 // Update a conversation with conversationId
 app.put('/conversations/:conversationId', conversations.update);

 // Delete a conversation with conversationId
 app.delete('/conversations/:conversationId', conversations.delete);
}