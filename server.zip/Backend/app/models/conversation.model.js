var mongoose = require('mongoose');
Schema = mongoose.Schema;

var conversationSchema = new Schema({
   phoneNumber1: String,
   phoneNumber2: String,
   conversations : [{
    messageText : String,
    timeSent : String,
    senderNumber: String
    }]
   },
   {
    timestamps: true // Saves createdAt and updatedAt as dates. createdAt will be our timestamp.
    });

module.exports = mongoose.model('conversation', conversationSchema);